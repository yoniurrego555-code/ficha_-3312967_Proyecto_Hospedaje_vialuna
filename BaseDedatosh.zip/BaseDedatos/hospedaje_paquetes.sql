-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: hospedaje
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `paquetes`
--

DROP TABLE IF EXISTS `paquetes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paquetes` (
  `IDPaquete` int NOT NULL AUTO_INCREMENT,
  `NombrePaquete` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `ImagenPaquete` blob,
  `Descripcion` text COLLATE utf8mb4_general_ci NOT NULL,
  `IDHabitacion` int DEFAULT NULL,
  `IDServicio` int DEFAULT NULL,
  `Precio` float DEFAULT NULL,
  `Estado` tinyint(1) NOT NULL,
  `ImagenUrl` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`IDPaquete`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paquetes`
--

LOCK TABLES `paquetes` WRITE;
/*!40000 ALTER TABLE `paquetes` DISABLE KEYS */;
INSERT INTO `paquetes` VALUES (2,'Aventura Natural',NULL,'Disfruta de una cabalgata en familia con nuestra amplia habitación familiar.\n\n✨ Beneficios del paquete:\n✓ Desayuno campestre incluido\n✓ Bebidas de hidratación\n✓ Fotografías digitales de la cabalgata',5,3,240000,1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2KM88nSbgaTsqGbf3aNrQaDOMR5ECpdDunA&s'),(3,'Tour Turístico',NULL,'Aventura individual con caminata ecológica guiada y cómoda habitación sencilla.\n\n✨ Beneficios del paquete:\n✓ Desayuno energético incluido\n✓ Bebida refrescante al finalizar\n✓ Kit de senderismo prestado (bastones)',4,5,175000,0,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkJjSz7ot8oOhogWsKJ91JZLgD5ofUvymADg&s'),(4,'Experiencia Premium',NULL,'Relajación total para parejas con sesión de spa y hermosa habitación para parejas.\n\n✨ Beneficios del paquete:\n✓ Desayuno a la habitación incluido\n✓ Bebida de bienvenida (Cóctel)\n✓ Kit de aromaterapia especial en el Spa',3,2,195000,1,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwJNfVQaaJX_OFb3iVQFHbaDfi_oscZFVYZg&s');
/*!40000 ALTER TABLE `paquetes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-02 20:01:37
