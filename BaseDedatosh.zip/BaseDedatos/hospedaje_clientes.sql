-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: hospedaje
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `NroDocumento` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `TipoDocumento` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Nombre` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Apellido` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Direccion` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Contrasena` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Telefono` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Estado` tinyint(1) DEFAULT NULL,
  `IDRol` int DEFAULT NULL,
  `Pais` varchar(100) COLLATE utf8mb4_general_ci DEFAULT 'Colombia',
  `Departamento` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`NroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES ('1023748168','CC','Yoni','Urrego','Calle 108','yoniurrego444@gmail.com',NULL,'3052786212',1,1,'Colombia','antioquia'),('1023748798','CC','Sarita','Urrego','Calle 108','saritaurrego@gmail.com','$2b$10$YbaIIeOPWXejSvCFlSw2RuobXqUouKxmjoAyaw9jwiYcKwi.GbFuW','3027984319',1,1,'Colombia','antioquia'),('123','CC','Diego','estrada','Calle 210','enrique342@gmail.es','$2b$10$rjO/Q.CqaNVcZ/H8GyfGzePwdItPtVZv/M4.JWCG3gw6qIAE1QeuK','12345678',1,1,'Colombia','Antioquia');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-02 20:01:20
